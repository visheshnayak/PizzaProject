package com.dao;

import java.util.List;

import com.pojo.Pizza;
import com.pojo.Topping;

public interface AdminDAO {
	
	int addTopping(Topping topping);
	int deleteTopping(String toppingname);
	int updateToppingPrice(String toppingname,int price);
	int addPizza(Pizza pizza);
	int deletePizza(String pizzaname);
	int updatePrice(int price,String name);
	List<Topping> showToppings();
	List<Pizza> showPizzas();

}
