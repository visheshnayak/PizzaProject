package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.MyConnection;
import com.pojo.Pizza;
import com.pojo.Topping;

public class AdminDAOImpl implements AdminDAO {

	@Override
	public int addTopping(Topping topping) {
		// TODO Auto-generated method stub
		int records=0;
		Connection connection=MyConnection.setConnection();
		String INSERT="insert into toppings(toppingprice,toppingname) values(?,?)";
		PreparedStatement ps ;
				try {
					ps= connection.prepareStatement(INSERT);
					ps.setInt(1, topping.getToppingprice());
					ps.setString(2, topping.getToppingname());
					records=ps.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
		
	}

	@Override
	public int deleteTopping(String toppingname) {
		// TODO Auto-generated method stub
		
		int records=0;
		Connection connection=MyConnection.setConnection();
		String DELETE="delete from toppings where toppingname=?";
				try {
					PreparedStatement ps = connection.prepareStatement(DELETE);
					ps.setString(1, toppingname);
					records=ps.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

	@Override
	public int addPizza(Pizza pizza) {
		// TODO Auto-generated method stub
		int records=0;
		Connection connection=MyConnection.setConnection();
		String ADDPIZZA="INSERT INTO pizza(pizzaname,ingredients,crust,type,baseprice) VALUES(?,?,?,?,?)";
				try {
					PreparedStatement ps = connection.prepareStatement(ADDPIZZA);
					ps.setString(1, pizza.getName());
					ps.setString(2, pizza.getIngredients());
					ps.setString(3, pizza.getCrust());
					ps.setString(4, pizza.getType());
					ps.setInt(5, pizza.getBaseprice());
					
					records=ps.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

	@Override
	public int deletePizza(String pizzaname) {
		// TODO Auto-generated method stub
		int records=0;
		Connection connection=MyConnection.setConnection();
		String DELETE="delete from Pizza where pizzaname=?";
				try {
					PreparedStatement ps = connection.prepareStatement(DELETE);
					ps.setString(1, pizzaname);
					records=ps.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

	@Override
	public int updatePrice(int price, String name) {
		// TODO Auto-generated method stub
		int records=0;
		Connection connection=MyConnection.setConnection();
		String DELETE="UPDATE pizza SET baseprice=? where pizzaname=?";
				try {
					PreparedStatement ps = connection.prepareStatement(DELETE);
					ps.setInt(1, price);
					ps.setString(2,name);
					records=ps.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

	@Override
	public int updateToppingPrice(String toppingname,int price) {
		// TODO Auto-generated method stub
		int records=0;
		Connection connection=MyConnection.setConnection();
		String UPDATE="Update toppings set toppingprice=? where toppingname=?";
				try {
					PreparedStatement ps = connection.prepareStatement(UPDATE);
					ps.setInt(1, price);

					ps.setString(2, toppingname);
					records=ps.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

	@Override
	public List<Topping> showToppings() {
		// TODO Auto-generated method stub
		List<Topping> records=new ArrayList<Topping>();
		Connection connection=MyConnection.setConnection();
		String UPDATE="Select * from toppings";
				try {
					PreparedStatement ps = connection.prepareStatement(UPDATE);
					
					ResultSet rs = ps.executeQuery();
					
					while(rs.next()){
						Topping topp = new Topping();
						topp.setToppingid(rs.getInt(1));
						topp.setToppingname(rs.getString(2));
						topp.setToppingprice(rs.getInt(3));
						records.add(topp);
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

	@Override
	public List<Pizza> showPizzas() {
		// TODO Auto-generated method stub
		List<Pizza> records=new ArrayList<Pizza>();
		Connection connection=MyConnection.setConnection();
		String UPDATE="Select * from pizza";
				try {
					PreparedStatement ps = connection.prepareStatement(UPDATE);
					
					ResultSet rs = ps.executeQuery();
					
					while(rs.next()){
						Pizza pizza = new Pizza();
						pizza.setPizzaid(rs.getInt(1));
						pizza.setName(rs.getString(2));
						pizza.setIngredients(rs.getString(3));
						pizza.setCrust(rs.getString(4));
						pizza.setType(rs.getString(5));
						pizza.setBaseprice(rs.getInt(6));
						records.add(pizza);
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return records;
	}

}
