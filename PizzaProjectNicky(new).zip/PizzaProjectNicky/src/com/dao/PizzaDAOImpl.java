package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.MyConnection;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.pojo.Pizza;

public class PizzaDAOImpl implements PizzaDAO {

	private Connection con = MyConnection.setConnection();
	
	@Override
	public Pizza showPizzaById(int pizzaid) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM pizza WHERE pizzaid=?";
		Pizza p = new Pizza();
		try {
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			
			ps.setInt(1, pizzaid);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				p.setPizzaid(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setIngredients(rs.getString(3));
				p.setCrust(rs.getString(4));
				p.setType(rs.getString(5));
				p.setBaseprice(rs.getInt(6));
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}

	@Override
	public List<Pizza> showAllPizza() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM pizza";
		List<Pizza> res = new ArrayList<>();
		try {
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
						
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Pizza p = new Pizza();
				
				p.setPizzaid(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setIngredients(rs.getString(3));
				p.setCrust(rs.getString(4));
				p.setType(rs.getString(5));
				p.setBaseprice(rs.getInt(6));
				
				res.add(p);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;	}

	@Override
	public int addPizza(Pizza pizza) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO pizza(pizzaname,ingredients,crust,type,baseprice) VALUES(?,?,?,?,?)";
		int rows=-1;
		try {
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			
			ps.setString(1, pizza.getName());
			ps.setString(2, pizza.getIngredients());
			ps.setString(3, pizza.getCrust());
			ps.setString(4, pizza.getType());
			ps.setInt(5, pizza.getBaseprice());
			
			rows = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rows;
	}

}
