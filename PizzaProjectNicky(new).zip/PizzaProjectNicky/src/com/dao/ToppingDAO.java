package com.dao;

import java.util.List;

import com.pojo.Topping;

public interface ToppingDAO {
	public List<Topping> showAllToppings();
	public List<Topping> showToppingByID(int toppingid);
	public int addTopping(Topping topping);

}
