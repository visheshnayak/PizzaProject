package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.MyConnection;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.pojo.Topping;

public class ToppingDAOImpl implements ToppingDAO {

	Connection con = MyConnection.setConnection();
	
	@Override
	public List<Topping> showAllToppings() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM toppings";
		List<Topping> res = new ArrayList<>();
		try {
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Topping p = new Topping();
				
				p.setToppingid(rs.getInt(1));
				p.setToppingname(rs.getString(2));
				p.setToppingprice(rs.getInt(3));
				
				res.add(p);
			}
		} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		return res;
	}

	@Override
	public List<Topping> showToppingByID(int toppingid) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM toppings WHERE toppingid=?";
		List<Topping> res = new ArrayList<>();
		try {
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			
			ps.setInt(1, toppingid);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Topping p = new Topping();
				
				p.setToppingid(rs.getInt(1));
				p.setToppingname(rs.getString(2));
				p.setToppingprice(rs.getInt(3));
				
				res.add(p);
			}
		} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		return res;
	}

	@Override
	public int addTopping(Topping topping) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO toppings(toppingname,toppingprice) VALUES(?,?)";
		int rows=-1;
		try {
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			
			ps.setString(1, topping.getToppingname());
			ps.setInt(5, topping.getToppingprice());
			
			rows = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rows;
	}

}
