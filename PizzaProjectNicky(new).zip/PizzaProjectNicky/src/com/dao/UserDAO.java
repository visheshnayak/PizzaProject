package com.dao;

import com.pojo.User;

public interface UserDAO {
	
 User validate(String username,String password);
  int Register(User user);
  int getUserIdByName(String username,String password);
  

}
