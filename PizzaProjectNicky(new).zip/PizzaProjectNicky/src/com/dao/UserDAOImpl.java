package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.MyConnection;
import com.pojo.User;

public class UserDAOImpl implements UserDAO
{

	public User validate(String email, String password) {
		Connection connection= MyConnection.setConnection();
		boolean status=false;
		ResultSet rs=null;
		String LOGIN_SQL ="select * from User where email=? AND password=?";
		User user =  new User();
		try {
			

			PreparedStatement ps=connection.prepareStatement(LOGIN_SQL);
			ps.setString(1,email);
			ps.setString(2,password);
			
			rs=ps.executeQuery();
//			status=rs.next();
			
			while(rs.next()){
				user.setUserid(rs.getInt(1));
				user.setEmail(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setName(rs.getString(4));
				user.setAddress(rs.getString(5));
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
		return user;
	}

	@Override
	public int Register(User user) {
		// TODO Auto-generated method stub
		Connection connection= MyConnection.setConnection();
		
		String REGISTER_SQL ="insert into user(email,password,name,address) values(?,?,?,?)";
		int records=0;
		
		
		try{
		PreparedStatement ps=connection.prepareStatement(REGISTER_SQL);
		ps.setString(1,user.getEmail());
		ps.setString(2,user.getPassword());
		ps.setString(3,user.getName());
		ps.setString(4,user.getAddress());
		
		records=ps.executeUpdate();
		
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return records;
		}

	@Override
	public int getUserIdByName(String email, String password) {
		// TODO Auto-generated method stub
		Connection connection= MyConnection.setConnection();
		boolean status=false;
		ResultSet rs=null;
		int userid=0;
		String LOGIN_SQL ="select userid from User where email=? AND password=?";
		User user =  new User();
		try {
			

			PreparedStatement ps=connection.prepareStatement(LOGIN_SQL);
			ps.setString(1,email);
			ps.setString(2,password);
			
			rs=ps.executeQuery();
//			status=rs.next();
			
			while(rs.next()){
				userid=rs.getInt(1);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
		return userid;
		
	}
	

	
}
