package com.pojo;

public class Topping {

	private int toppingid,toppingprice;
	private String toppingname;
	
	public Topping() {
		// TODO Auto-generated constructor stub

		this.toppingprice = 0;
		this.toppingname = "";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((toppingname == null) ? 0 : toppingname.hashCode());
		result = prime * result + toppingid;
		result = prime * result + toppingprice;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Topping other = (Topping) obj;
		if (toppingname == null) {
			if (other.toppingname != null)
				return false;
		} else if (!toppingname.equals(other.toppingname))
			return false;
		if (toppingid != other.toppingid)
			return false;
		if (toppingprice != other.toppingprice)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Topping [toppingid=" + toppingid + ", toppingprice=" + toppingprice + ", toppingname=" + toppingname
				+ "]";
	}

	public Topping(int toppingid, int toppingprice, String toppingname) {
		super();
		this.toppingprice = toppingprice;
		this.toppingname = toppingname;
	}

	public int getToppingid() {
		return toppingid;
	}

	public void setToppingid(int toppingid) {
		this.toppingid = toppingid;
	}

	public int getToppingprice() {
		return toppingprice;
	}

	public void setToppingprice(int toppingprice) {
		this.toppingprice = toppingprice;
	}

	public String getToppingname() {
		return toppingname;
	}

	public void setToppingname(String toppingname) {
		this.toppingname = toppingname;
	}
}
