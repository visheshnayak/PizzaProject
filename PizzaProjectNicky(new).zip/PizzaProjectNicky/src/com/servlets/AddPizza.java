package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.AdminDAO;
import com.dao.AdminDAOImpl;
import com.pojo.Pizza;
import com.pojo.Topping;

/**
 * Servlet implementation class AddPizza
 */
@WebServlet("/AddPizza")
public class AddPizza extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPizza() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Pizza pizza= new Pizza();
		pizza.setName(request.getParameter("pizzaname"));
		pizza.setBaseprice(Integer.parseInt(request.getParameter("baseprice")));
		String[] ingredients = request.getParameterValues("topping");
		String topping="";
		if(ingredients!=null){
			topping = ingredients[0];
		for(int i = 1; i<ingredients.length;i++){
			topping = topping+","+ingredients[i];
		}
		}
		
		pizza.setIngredients(topping);
		pizza.setType(request.getParameter("Type"));
		
		AdminDAO dao=new AdminDAOImpl();
		String[] crust = request.getParameterValues("crust");
		if(crust!=null){
			int records_inserted=0;
			for(int i=0;i<crust.length;i++){
				pizza.setCrust(crust[i]);
				records_inserted=dao.addPizza(pizza);
				
			}
			
			response.setContentType("text/html");
		    PrintWriter wr =response.getWriter();
		
		    wr.println("<html>");
		    wr.println("<body>");
		    if(records_inserted>0)
		    {
			wr.println("RECORD INSERTED! WELCOME" +pizza.getName());
			RequestDispatcher dispatcher = request.getRequestDispatcher("admin.html");
			dispatcher.forward(request, response);
		    }
		    else{
			wr.println("Sorry!! Record not inserted");
		    }
		    wr.println("</body>");
		    wr.println("</html>");
			
		}
		
		//output
		
	}
	}

	
	


