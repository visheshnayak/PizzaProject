package com.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDAOImpl;
import com.pojo.Order;
import com.pojo.User;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String String = null;

	/**
	 * Default constructor. 
	 */
	public LoginServlet() {
		// TODO Auto-generated constructor stub
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	
		String n1=request.getParameter("email");
		String n2=request.getParameter("password");
		RequestDispatcher dispatcher=null;
		if(n1.equals("admin@admin.com")&& n2.equals("admin123")){
			dispatcher =  request.getRequestDispatcher("admin.html");
			dispatcher.forward(request, response);

		}
		else{
//			PrintWriter writer = response.getWriter();
//			response.setContentType("text/html");
			UserDAOImpl dao=new UserDAOImpl();

			int userid = dao.getUserIdByName(n1, n2);
			HttpSession session=request.getSession();
			if(session!=null)
			{
				session.setAttribute("userid", userid);
				session.setAttribute("list", new ArrayList<Order>());
			}

			User u = dao.validate(n1,n2);
			
			if(!u.getName().equals(""))
			{
//				writer.println("welcome");
				dispatcher = request.getRequestDispatcher("order.jsp");
				dispatcher.forward(request, response);
			}
			else{
//				writer.println("not reg");
			}
		}
		
	}
}
