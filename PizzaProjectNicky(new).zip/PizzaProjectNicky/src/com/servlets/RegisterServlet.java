package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDAOImpl;
import com.pojo.User;



/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		User user=new User();
		user.setName(request.getParameter("name"));
		user.setPassword(request.getParameter("password"));
		user.setEmail(request.getParameter("email"));
		user.setAddress(request.getParameter("address"));
		
	
		//output
		UserDAOImpl dao=new UserDAOImpl();
		int records_inserted=dao.Register(user);
		response.setContentType("text/html");
		PrintWriter writer = response.getWriter();
		
			
				
	writer.println("<html>");
  	writer.println("<body>");
  	if(records_inserted > 0)
  	{
  		writer.println("RECORD INSERTED ! WELCOME" +user.getName());
  		RequestDispatcher dispatcher= request.getRequestDispatcher("index.jsp");
  		dispatcher.forward(request, response);
  	}
  	else{
  		writer.println("Sorry !! record not inserted");
  	}
  	writer.println("password"+user.getPassword());
  	writer.println("email"+user.getEmail());
  	writer.println("address"+user.getAddress());
		writer.println("</body>");
		writer.println("</html>");
		
	}


	}

