package com.DAO;

import java.util.List;

import com.pojo.Crust;

public interface CrustDAO {
	public List<Crust> showAllCrusts();
	public Crust showCrustByName(String crustname);
	public Integer addCrust(Crust Crust);
	public Integer deleteCrustByName(String crustname);
	public Integer updateCrustByName(int baseprice, String crustname);

}
