package com.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Crust;

public class CrustDAOImpl implements CrustDAO {
	private static SessionFactory sf = new Configuration().configure().buildSessionFactory();

	@Override
	public List<Crust> showAllCrusts() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Crust> res = session.createCriteria(Crust.class).list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public Crust showCrustByName(String crustname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Crust.class);
		cr.add(Restrictions.eq("crustname", crustname));

		List<Crust> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res.get(0);
	}

	@Override
	public Integer addCrust(Crust Crust) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Integer Crustid = (Integer) session.save(Crust);
		
		tr.commit();
		session.close();
		
		return Crustid;
	}

	@Override
	public Integer deleteCrustByName(String crustname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		session.delete(showCrustByName(crustname));

		tr.commit();
		session.close();
		
		return 69;
	}

	@Override
	public Integer updateCrustByName(int baseprice, String crustname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Crust Crusts = showCrustByName(crustname);
		
		Crusts.setCrustprice(baseprice);
		session.update(Crusts);
		
		tr.commit();
		session.close();
		
		return 69;
	}

}
