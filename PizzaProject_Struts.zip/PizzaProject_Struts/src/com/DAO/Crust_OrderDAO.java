package com.DAO;

import java.util.List;

import com.pojo.Crust_Order;

public interface Crust_OrderDAO {
	public List<Crust_Order> showCrustsInPizza(int orderid);

}
