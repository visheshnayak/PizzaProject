package com.DAO;

import java.util.List;

import com.pojo.Order;

public interface OrderDAO {
	public int addOrder(Order order);
	
	public List<Order> showOrderbySession(int userid, String sessionid);
	public List<Order> showOrderbyUser(int userid);
	public List<Order> showAllOrders();

}
