package com.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Order;

public class OrderDAOImpl implements OrderDAO {
	private SessionFactory sf = new Configuration().configure().buildSessionFactory();

	@Override
	public int addOrder(Order order) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		int res = (int) session.save(order);
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public List<Order> showOrderbySession(int userid, String sessionid) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Order.class);
		cr.add(Restrictions.eq("sessionid", sessionid));
		cr.add(Restrictions.eq("userid", userid));
		
		List<Order> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public List<Order> showOrderbyUser(int userid) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Order.class);
		cr.add(Restrictions.eq("userid", userid));
		
		List<Order> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public List<com.pojo.Order> showAllOrders() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Order> res = session.createCriteria(Order.class).list();
		
		tr.commit();
		session.close();
		
		return res;
	}

}
