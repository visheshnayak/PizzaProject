package com.DAO;

import java.util.List;

import com.pojo.Pizza;

public interface PizzaDAO {
	public Pizza showPizzaById(int pizzaid);
	public List<Pizza> showAllPizza();
	public Integer addPizza(Pizza pizza);
	public List<Pizza> showPizzaByName(String pizzaname);
	public Integer deletePizzaByName(String pizzaname);
	public Integer updatePizzaByName(int baseprice, String pizzaname);
	public List<Pizza> showPizzaByType(String type);


}
