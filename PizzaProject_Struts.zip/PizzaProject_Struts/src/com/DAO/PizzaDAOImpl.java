package com.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Pizza;

public class PizzaDAOImpl implements PizzaDAO {
	private static SessionFactory sf = new Configuration().configure().buildSessionFactory();

	@Override
	public Pizza showPizzaById(int pizzaid) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Pizza.class);
		cr.add(Restrictions.eq("pizzaid", pizzaid));

		List<Pizza> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res.get(0);
	}

	@Override
	public List<Pizza> showAllPizza() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Pizza> res = session.createCriteria(Pizza.class).list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public Integer addPizza(Pizza pizza) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Integer pizzaid = (Integer) session.save(pizza);

		tr.commit();
		session.close();
		
		return pizzaid;
	}

	@Override
	public List<Pizza> showPizzaByName(String pizzaname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Pizza.class);
		cr.add(Restrictions.eq("pizzaname", pizzaname));

		List<Pizza> res = cr.list();
	
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public Integer deletePizzaByName(String pizzaname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Pizza> pizzas = showPizzaByName(pizzaname);
		
		for(Pizza i : pizzas)
			session.delete(i);
		
		tr.commit();
		session.close();
		
		return 69;
	}

	@Override
	public Integer updatePizzaByName(int baseprice, String pizzaname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Pizza> pizzas = showPizzaByName(pizzaname);
		
		for(Pizza i : pizzas){
			i.setBaseprice(baseprice);
			session.update(i);
		}
		tr.commit();
		session.close();
		
		return 69;
	}

	@Override
	public List<Pizza> showPizzaByType(String type) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Pizza.class);
		cr.add(Restrictions.eq("type", type));

		List<Pizza> res = cr.list();
	
		tr.commit();
		session.close();
		
		return res;
	}

}
