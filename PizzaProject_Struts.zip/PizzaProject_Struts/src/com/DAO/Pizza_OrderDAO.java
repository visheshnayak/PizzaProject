package com.DAO;

import java.util.List;

import com.pojo.Pizza_Order;

public interface Pizza_OrderDAO {
	public List<Pizza_Order> showPizzaInOrder(int orderid);
	
}
