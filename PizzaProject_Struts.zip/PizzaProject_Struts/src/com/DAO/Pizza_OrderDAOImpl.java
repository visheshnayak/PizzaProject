package com.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Pizza_Order;

public class Pizza_OrderDAOImpl implements Pizza_OrderDAO {	
	private static SessionFactory sf = new Configuration().configure().buildSessionFactory();

	@Override
	public List<Pizza_Order> showPizzaInOrder(int orderid) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Pizza_Order.class);
		cr.add(Restrictions.eq("orderid", orderid));

		List<Pizza_Order> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res;
	}

}
