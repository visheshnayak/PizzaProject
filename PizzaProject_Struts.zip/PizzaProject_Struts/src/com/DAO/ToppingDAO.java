package com.DAO;

import java.util.List;

import com.pojo.Topping;

public interface ToppingDAO {
	public List<Topping> showAllToppings();
	public Topping showToppingByName(String toppingname);
	public Integer addTopping(Topping topping);
	public Integer deleteToppingByName(String toppingname);
	public Integer updateToppingByName(int baseprice, String toppingname);

}
