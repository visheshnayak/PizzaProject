package com.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Topping;

public class ToppingDAOImpl implements ToppingDAO {
	private static SessionFactory sf = new Configuration().configure().buildSessionFactory();

	@Override
	public List<Topping> showAllToppings() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Topping> res = session.createCriteria(Topping.class).list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public Topping showToppingByName(String name) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Topping.class);
		cr.add(Restrictions.eq("toppingname", name));

		List<Topping> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res.get(0);
	}

	@Override
	public Integer addTopping(Topping topping) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Integer toppingid = (Integer) session.save(topping);
		
		tr.commit();
		session.close();
		
		return toppingid;
	}

	@Override
	public Integer deleteToppingByName(String toppingname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		session.delete(showToppingByName(toppingname));

		tr.commit();
		session.close();
		
		return 69;
	}

	@Override
	public Integer updateToppingByName(int baseprice, String toppingname) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Topping toppings = showToppingByName(toppingname);
		
		toppings.setToppingprice(baseprice);
		session.update(toppings);
		
		tr.commit();
		session.close();
		
		return 69;
	}

}
