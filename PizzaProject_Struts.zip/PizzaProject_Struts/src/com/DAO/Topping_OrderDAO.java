package com.DAO;

import java.util.List;

import com.pojo.Topping_Order;

public interface Topping_OrderDAO {
	public List<Topping_Order> showToppingsInPizza(int pizzaid);

}
