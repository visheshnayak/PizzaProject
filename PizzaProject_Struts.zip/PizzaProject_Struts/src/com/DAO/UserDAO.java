package com.DAO;

import java.util.List;

import com.pojo.User;

public interface UserDAO {
	public Integer addUser(User user);
	public List<User> getAllUser();
	public List<User> getUserById(int userid);
	public User validateUser(String email, String password);
	public int getUserIdByName(String email);
}
