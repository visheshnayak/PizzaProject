package com.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.User;

public class UserDAOImpl implements UserDAO
{
	private static SessionFactory sf = new Configuration().configure().buildSessionFactory(); 

	@Override
	public Integer addUser(User user) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Integer userid = (Integer) session.save(user);
		
		tr.commit();
		session.close();
		
		return userid;
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<User> res = session.createCriteria(User.class).list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public List<User> getUserById(int userid) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.eq("userid", userid));

		List<User> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public User validateUser(String email, String password) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.eq("email", email));
		cr.add(Restrictions.eq("password", password));

		List<User> res = cr.list();

		tr.commit();
		session.close();
		
		return res.get(0);
	}

	@Override
	public int getUserIdByName(String email) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.eq("email", email));

		List<User> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res.get(0).getUserid();
	}

}
