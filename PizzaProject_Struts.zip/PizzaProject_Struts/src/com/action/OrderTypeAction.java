package com.action;

import java.util.ArrayList;
import java.util.List;

import com.DAO.PizzaDAOImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Pizza;

public class OrderTypeAction extends ActionSupport {
	
	List<Pizza> pizzas = new ArrayList<>(); 
	public OrderTypeAction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderTypeAction(List<Pizza> pizzas) {
		super();
		this.pizzas = pizzas;
	}

	@Override
	public String toString() {
		return "OrderTypeAction [pizzas=" + pizzas + "]";
	}

	public List<Pizza> getPizzas() {
		return pizzas;
	}

	public void setPizzas(List<Pizza> pizzas) {
		this.pizzas = pizzas;
	}

	public String veg()
	{
		pizzas = new PizzaDAOImpl().showPizzaByType("veg");
		return SUCCESS;
	}
	
	public String nonveg()
	{
		pizzas = new PizzaDAOImpl().showPizzaByType("nonveg");
		return SUCCESS;
	}

}
