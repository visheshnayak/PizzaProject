package com.action;

import java.util.ArrayList;
import java.util.List;

import com.DAO.OrderDAOImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Order;
import com.pojo.Pizza_Order;
import com.pojo.Topping_Order;

public class PlaceOrderAction extends ActionSupport {
	private Order order = new Order();
	private List<Pizza_Order> pizzas = new ArrayList<>();
	private List<Topping_Order> toppings = new ArrayList<>();
	
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public List<Pizza_Order> getPizzas() {
		return pizzas;
	}
	public void setPizzas(List<Pizza_Order> pizzas) {
		this.pizzas = pizzas;
	}
	public List<Topping_Order> getToppings() {
		return toppings;
	}
	public void setToppings(List<Topping_Order> toppings) {
		this.toppings = toppings;
	}
	public PlaceOrderAction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PlaceOrderAction(Order order, List<Pizza_Order> pizzas, List<Topping_Order> toppings) {
		super();
		this.order = order;
		this.pizzas = pizzas;
		this.toppings = toppings;
	}
	@Override
	public String toString() {
		return "PlaceOrderAction [order=" + order + ", pizzas=" + pizzas + ", toppings=" + toppings + "]";
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println(order);
//		OrderDAOImpl od = new OrderDAOImpl();
//		od.addOrder(order);
		
		return SUCCESS;
	}

}
