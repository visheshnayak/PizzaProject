package com.main;

import com.DAO.OrderDAOImpl;
import com.pojo.Order;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Order order = new Order("1", 2, null, null);
		OrderDAOImpl od = new OrderDAOImpl();
		od.addOrder(order);

	}

}
