package com.pojo;

import javax.persistence.*;

@Entity
public class Crust {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int crustid;
	
	private String crustname;
	private int crustprice;
	
	public int getCrustid() {
		return crustid;
	}
	public void setCrustid(int crustid) {
		this.crustid = crustid;
	}
	public String getCrustname() {
		return crustname;
	}
	public void setCrustname(String crustname) {
		this.crustname = crustname;
	}
	public int getCrustprice() {
		return crustprice;
	}
	public void setCrustprice(int crustprice) {
		this.crustprice = crustprice;
	}
	public Crust(String crustname, int crustprice) {
		super();
		this.crustname = crustname;
		this.crustprice = crustprice;
	}
	@Override
	public String toString() {
		return "Crust [crustid=" + crustid + ", crustname=" + crustname + ", crustprice=" + crustprice + "]";
	}
	public Crust() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
