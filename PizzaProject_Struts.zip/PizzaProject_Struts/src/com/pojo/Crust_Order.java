package com.pojo;

import javax.persistence.*;

@Entity
public class Crust_Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int crustid;
	
	private String crustname;
	private int crustprice;
	
	@OneToOne
	@JoinColumn(name="pizzaid", nullable=false)
	private Pizza_Order pizza;

	public int getCrustid() {
		return crustid;
	}

	public void setCrustid(int crustid) {
		this.crustid = crustid;
	}

	public String getCrustname() {
		return crustname;
	}

	public void setCrustname(String crustname) {
		this.crustname = crustname;
	}

	public int getCrustprice() {
		return crustprice;
	}

	public void setCrustprice(int crustprice) {
		this.crustprice = crustprice;
	}

	public Pizza_Order getPizza() {
		return pizza;
	}

	public void setPizza(Pizza_Order pizza) {
		this.pizza = pizza;
	}

	public Crust_Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Crust_Order(String crustname, int crustprice, Pizza_Order pizza) {
		super();
		this.crustname = crustname;
		this.crustprice = crustprice;
		this.pizza = pizza;
	}

	@Override
	public String toString() {
		return "Crust_Order [crustid=" + crustid + ", crustname=" + crustname + ", crustprice=" + crustprice
				+ ", pizza=" + pizza + "]";
	}
	
}
