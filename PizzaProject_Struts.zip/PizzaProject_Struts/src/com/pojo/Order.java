package com.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderid;
	
	private String sessionid;
	private int totalprice;
	
	@OneToMany(mappedBy="order", cascade=CascadeType.ALL)
	List<Pizza_Order> pizzas = new ArrayList<Pizza_Order>();
	
	@ManyToOne
	@JoinColumn(name="userid", nullable=false)
	private User user;

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getSessionid() {
		return sessionid;
	}

	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	public int getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}

	public List<Pizza_Order> getPizzas() {
		return pizzas;
	}

	public void setPizzas(List<Pizza_Order> pizzas) {
		this.pizzas = pizzas;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", sessionid=" + sessionid + ", totalprice=" + totalprice + ", pizzas="
				+ pizzas + ", user=" + user + "]";
	}

	public Order(String sessionid, int totalprice, List<Pizza_Order> pizzas, User user) {
		super();
		this.sessionid = sessionid;
		this.totalprice = totalprice;
		this.pizzas = pizzas;
		this.user = user;
	}
	
}
