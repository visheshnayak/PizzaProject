package com.pojo;

import javax.persistence.*;

@Entity
public class Pizza {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pizzaid;
	
	private String pizzaname;
	private String ingredients;
	private String type;
	private int baseprice;
	public int getPizzaid() {
		return pizzaid;
	}
	public void setPizzaid(int pizzaid) {
		this.pizzaid = pizzaid;
	}
	public String getPizzaname() {
		return pizzaname;
	}
	public void setPizzaname(String pizzaname) {
		this.pizzaname = pizzaname;
	}
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getBaseprice() {
		return baseprice;
	}
	public void setBaseprice(int baseprice) {
		this.baseprice = baseprice;
	}
	public Pizza() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Pizza [pizzaid=" + pizzaid + ", pizzaname=" + pizzaname + ", ingredients=" + ingredients + ", type="
				+ type + ", baseprice=" + baseprice + "]";
	}
	public Pizza(String pizzaname, String ingredients, String type, int baseprice) {
		super();
		this.pizzaname = pizzaname;
		this.ingredients = ingredients;
		this.type = type;
		this.baseprice = baseprice;
	}

}
