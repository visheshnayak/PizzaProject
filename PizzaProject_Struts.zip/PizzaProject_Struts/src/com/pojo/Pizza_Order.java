package com.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Pizza_Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pizzaid;
	
	private String pizzaname;
	private String ingredients;
	private String type;
	private int baseprice;
	
	@OneToMany(mappedBy="pizza", cascade=CascadeType.ALL)
	private List<Topping_Order> toppings = new ArrayList<>();
	
	@OneToOne(mappedBy="pizza", cascade=CascadeType.ALL)
	private Crust_Order crust;
	
	@ManyToOne
	@JoinColumn(name="orderid", nullable=false)
	private Order order;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public int getPizzaid() {
		return pizzaid;
	}

	public void setPizzaid(int pizzaid) {
		this.pizzaid = pizzaid;
	}

	public String getPizzaname() {
		return pizzaname;
	}

	public void setPizzaname(String pizzaname) {
		this.pizzaname = pizzaname;
	}

	public String getIngredients() {
		return ingredients;
	}

	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getBaseprice() {
		return baseprice;
	}

	public void setBaseprice(int baseprice) {
		this.baseprice = baseprice;
	}

	public List<Topping_Order> getToppings() {
		return toppings;
	}

	public void setToppings(List<Topping_Order> toppings) {
		this.toppings = toppings;
	}

	public Crust_Order getCrust() {
		return crust;
	}

	public void setCrust(Crust_Order crust) {
		this.crust = crust;
	}

	public Pizza_Order(String pizzaname, String ingredients, String type, int baseprice, List<Topping_Order> toppings,
			Crust_Order crust) {
		super();
		this.pizzaname = pizzaname;
		this.ingredients = ingredients;
		this.type = type;
		this.baseprice = baseprice;
		this.toppings = toppings;
		this.crust = crust;
	}

	public Pizza_Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Pizza_Order [pizzaid=" + pizzaid + ", pizzaname=" + pizzaname + ", ingredients=" + ingredients
				+ ", type=" + type + ", baseprice=" + baseprice + ", toppings=" + toppings + ", crust=" + crust + "]";
	}
	

}
