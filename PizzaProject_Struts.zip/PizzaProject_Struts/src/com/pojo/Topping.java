package com.pojo;

import javax.persistence.*;

@Entity
public class Topping {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int toppingid;
	private String toppingname;
	private int toppingprice;
	
	public int getToppingid() {
		return toppingid;
	}
	public void setToppingid(int toppingid) {
		this.toppingid = toppingid;
	}
	public String getToppingname() {
		return toppingname;
	}
	public void setToppingname(String toppingname) {
		this.toppingname = toppingname;
	}
	public int getToppingprice() {
		return toppingprice;
	}
	public void setToppingprice(int toppingprice) {
		this.toppingprice = toppingprice;
	}
	public Topping() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Topping(String toppingname, int toppingprice) {
		super();
		this.toppingname = toppingname;
		this.toppingprice = toppingprice;
	}
	@Override
	public String toString() {
		return "Topping [toppingid=" + toppingid + ", toppingname=" + toppingname + ", toppingprice=" + toppingprice
				+ "]";
	}
	

}
