package com.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Topping_Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int toppingid;
	
	private String toppingname;
	private int toppingprice;
	
	@ManyToOne
	@JoinColumn(name="pizzaid", nullable=false)
	private Pizza_Order pizza;

	public int getToppingid() {
		return toppingid;
	}

	public void setToppingid(int toppingid) {
		this.toppingid = toppingid;
	}

	public String getToppingname() {
		return toppingname;
	}

	public void setToppingname(String toppingname) {
		this.toppingname = toppingname;
	}

	public int getToppingprice() {
		return toppingprice;
	}

	public void setToppingprice(int toppingprice) {
		this.toppingprice = toppingprice;
	}

	public Pizza_Order getPizza() {
		return pizza;
	}

	public void setPizza(Pizza_Order pizza) {
		this.pizza = pizza;
	}

	@Override
	public String toString() {
		return "Topping_Order [toppingid=" + toppingid + ", toppingname=" + toppingname + ", toppingprice="
				+ toppingprice + ", pizza=" + pizza + "]";
	}

	public Topping_Order(String toppingname, int toppingprice, Pizza_Order pizza) {
		super();
		this.toppingname = toppingname;
		this.toppingprice = toppingprice;
		this.pizza = pizza;
	}

	public Topping_Order() {
		super();
		// TODO Auto-generated constructor stub
	}
}
